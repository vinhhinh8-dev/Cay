package com.ferra13671.BThack.managers;

import com.ferra13671.BThack.BThack;
import com.ferra13671.BThack.api.module.Module;
import com.ferra13671.BThack.api.utils.Rotation;
import com.ferra13671.BThack.utils.MathUtils;
import com.ferra13671.MegaEvents.Base.EventTarget;
import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.concurrent.PriorityBlockingQueue;

public class RotationManager {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final PriorityBlockingQueue<Rotation> queue =
            new PriorityBlockingQueue<>(11, this::compareRotations);
    @Getter private Rotation rotation = null;

    private float prevFixYaw;
    private float prevYaw;
    private float prevPitch;

    @Getter private float serverYaw;
    @Getter private float serverPitch;

    private float prevRenderYaw, prevRenderPitch;
    private long lastRenderTime = 0L;

    /** Priority mặc định theo tên module — thêm module của bạn vào đây. */
    private static final HashMap<String, Integer> PRIORITIES = new HashMap<>();
    static {
        PRIORITIES.put("KillAura", 1);
        PRIORITIES.put("AutoCrystal", 2);
        PRIORITIES.put("SpeedMine", 3);
        PRIORITIES.put("SelfFill", 4);
    }

    public RotationManager() {
        BThack.EVENT_BUS.register(this);
    }

    // ============ EVENTS ============

    @EventTarget
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        queue.removeIf(r -> System.currentTimeMillis() - r.getTime() > 100);
        rotation = queue.peek();
        if (rotation == null) return;
        lastRenderTime = System.currentTimeMillis();
    }

    @EventTarget
    public void onUpdateMovement(UpdateMovementEvent event) {
        if (rotation == null) return;

        prevYaw = mc.player.getYaw();
        prevPitch = mc.player.getPitch();

        mc.player.setYaw(rotation.getYaw());
        mc.player.setPitch(rotation.getPitch());
    }

    @EventTarget
    public void onUpdateMovementPost(UpdateMovementEvent.Post event) {
        if (rotation == null) return;
        mc.player.setYaw(prevYaw);
        mc.player.setPitch(prevPitch);
    }

    @EventTarget
    public void onUpdateVelocity(UpdateVelocityEvent event) {
        if (mc.player == null) return;
        if (rotation == null) return;

        event.setVelocity(movementInputToVelocity(event.getMovementInput(), event.getSpeed(), rotation.getYaw()));
        event.setCancelled(true);
    }

    @EventTarget
    public void onKeyboardTick(KeyboardTickEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        float movementForward = event.getMovementForward();
        float movementSideways = event.getMovementSideways();

        float delta = (mc.player.getYaw() - rotation.getYaw()) * MathHelper.RADIANS_PER_DEGREE;

        float cos = MathHelper.cos(delta);
        float sin = MathHelper.sin(delta);

        event.setMovementForward(Math.round(movementForward * cos + movementSideways * sin));
        event.setMovementSideways(Math.round(movementSideways * cos - movementForward * sin));
        event.setCancelled(true);
    }

    @EventTarget
    public void onPlayerJump(PlayerJumpEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        prevFixYaw = mc.player.getYaw();
        mc.player.setYaw(rotation.getYaw());
    }

    @EventTarget
    public void onPlayerJumpPost(PlayerJumpEvent.Post event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        mc.player.setYaw(prevFixYaw);
    }

    @EventTarget
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null) return;

        if (event.getPacket() instanceof PlayerMoveC2SPacket packet) {
            if (!packet.changesLook()) return;

            serverYaw = packet.getYaw(mc.player.getYaw());
            serverPitch = packet.getPitch(mc.player.getPitch());
        }
    }

    // ============ ROTATE API ============

    public void rotate(float[] rotations, int priority) {
        rotate(rotations[0], rotations[1], priority);
    }

    public void rotate(float yaw, float pitch, int priority) {
        queue.removeIf(r -> r.getModule() == null && r.getPriority() == priority);
        queue.add(new Rotation(yaw, pitch, priority));
    }

    public void rotate(float[] rotations, Module module) {
        rotate(rotations[0], rotations[1], module);
    }

    public void rotate(float yaw, float pitch, Module module) {
        queue.removeIf(r -> r.getModule() == module);
        queue.add(new Rotation(yaw, pitch, module, getModulePriority(module)));
    }

    public void rotate(float[] rotations, Module module, int priority) {
        rotate(rotations[0], rotations[1], module, priority);
    }

    public void rotate(float yaw, float pitch, Module module, int priority) {
        queue.removeIf(r -> r.getModule() == module);
        queue.add(new Rotation(yaw, pitch, module, priority));
    }

    public void packetRotate(float[] rotations) {
        packetRotate(rotations[0], rotations[1]);
    }

    public void packetRotate(float yaw, float pitch) {
        if (serverYaw == yaw && serverPitch == pitch) return;
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                Managers.POSITION_MANAGER.getServerX(),
                Managers.POSITION_MANAGER.getServerY(),
                Managers.POSITION_MANAGER.getServerZ(),
                yaw, pitch,
                Managers.POSITION_MANAGER.isServerOnGround(),
                mc.player.horizontalCollision
        ));
    }

    public boolean inRenderTime() {
        return System.currentTimeMillis() - lastRenderTime < 1000;
    }

    public float[] getRenderRotations() {
        float from = MathUtils.wrapAngle(prevRenderYaw);
        float to = MathUtils.wrapAngle(rotation == null ? mc.player.getYaw() : getServerYaw());
        float delta = to - from;
        if (delta > 180) delta -= 360;
        else if (delta < -180) delta += 360;

        float progress = Math.min(1.0f, (System.currentTimeMillis() - lastRenderTime) / 1000.0f);
        float yaw = MathHelper.lerp(progress, from, from + delta);
        float pitch = MathHelper.lerp(progress, prevRenderPitch,
                rotation == null ? mc.player.getPitch() : getServerPitch());

        prevRenderYaw = yaw;
        prevRenderPitch = pitch;
        return new float[]{yaw, pitch};
    }

    public int getModulePriority(Module module) {
        return PRIORITIES.getOrDefault(module.getName(), 0);
    }

    private int compareRotations(Rotation target, Rotation rotation) {
        if (target.getPriority() == rotation.getPriority())
            return -Long.compare(target.getTime(), rotation.getTime());
        return -Integer.compare(target.getPriority(), rotation.getPriority());
    }

    /** Thay thế EntityAccessor.invokeMovementInputToVelocity của Sydney. */
    private static Vec3d movementInputToVelocity(Vec3d movementInput, float speed, float yaw) {
        double d = movementInput.lengthSquared();
        if (d < 1.0E-7) return Vec3d.ZERO;
        Vec3d vec = (d > 1.0 ? movementInput.normalize() : movementInput).multiply(speed);
        float f = MathHelper.sin(yaw * 0.017453292F);
        float g = MathHelper.cos(yaw * 0.017453292F);
        return new Vec3d(vec.x * g - vec.z * f, vec.y, vec.z * g + vec.x * f);
    }
}