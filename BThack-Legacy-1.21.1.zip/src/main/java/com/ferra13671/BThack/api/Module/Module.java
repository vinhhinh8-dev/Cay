package com.ferra13671.BThack.api.Module;

import com.ferra13671.BThack.BThack;
import com.ferra13671.BThack.core.Client.ModuleList;
import com.ferra13671.BThack.api.Category.Categories;
import com.ferra13671.BThack.api.Category.Category;
import com.ferra13671.BThack.api.Managers.Managers;
import com.ferra13671.BThack.api.Managers.managers.Setting.Settings.Setting;
import com.ferra13671.BThack.api.SoundSystem.SoundSystem;
import com.ferra13671.BThack.api.SoundSystem.Sounds;
import com.ferra13671.BThack.api.Utils.ChatUtils;
import com.ferra13671.BThack.impl.HudComponents.ArrayListComponent;
import com.ferra13671.SimpleLanguageSystem.LanguageSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Formatting;

import java.lang.reflect.Field;

public class Module {
    private final ModuleInfo moduleInfo = getClass().getAnnotation(ModuleInfo.class);
    public final String name = moduleInfo.name();
    private final String description = moduleInfo.description();
    private final Category category = Categories.get(moduleInfo.category());
    private final boolean autoEnabled = moduleInfo.autoEnabled();

    private int keyCode = moduleInfo.key();
    public boolean toggled;

    public String arrayListInfo = "";

    public boolean visible = true;
    public boolean allowRemapVisible = true;
    public boolean allowRemapKeyCode = true;

    public static final MinecraftClient mc = MinecraftClient.getInstance();

    public void initSettings() {
        if (category == null) throw new IllegalStateException("Category equals null");
        for (Field field : getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                if (field.get(this) instanceof Setting<?> setting && !setting.isInCategory())
                    Managers.SETTINGS_MANAGER.addModuleSetting(setting);
            } catch (Exception e) {
                BThack.error(e.getMessage());
            }
        }
    }

    public String getArrayListName() {
        return name + (arrayListInfo.isEmpty() ? "" : Formatting.GRAY + "[" + Formatting.WHITE +  arrayListInfo + Formatting.GRAY + "]");
    }

    public boolean isEnabled() {
        return toggled;
    }

    public boolean isAutoEnabled() {
        return autoEnabled;
    }

    public int getKey() {
        return keyCode;
    }

    public static boolean nullCheck() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null || mc.world == null;
    }

    public void onEnable() {
        BThack.EVENT_BUS.register(this);
    }

    public void onDisable() {
        BThack.EVENT_BUS.unregister(this);
    }

    public void onChangeSetting(Setting<?> setting) {}

    public void playOnSound() {
        if (ModuleList.clientSettings.moduleToggleSound.getValue())
            SoundSystem.playSound(Sounds.MODULE_ON, ModuleList.clientSettings.soundVolume.getValue().floatValue());
    }

    public void playOffSound() {
        if (ModuleList.clientSettings.moduleToggleSound.getValue())
            SoundSystem.playSound(Sounds.MODULE_OFF, ModuleList.clientSettings.soundVolume.getValue().floatValue());
    }


    public void setKey(int key) {
        this.keyCode = key;
    }

    public Category getCategory() {
        return category;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        if (description.startsWith("lang.")) {
            return LanguageSystem.translate(description);
        } else {
            return this.description;
        }
    }

    public String getChatName() {
        return "[" + this.name + "]";
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        if (this.visible) {
            if (isEnabled()) ArrayListComponent.addModule(this);
        } else ArrayListComponent.removeModule(this);
    }

    public boolean isVisible() {
        return visible;
    }

    public void sendNotification(String text) {
        if (ModuleList.chatNotifications.isEnabled() && ModuleList.chatNotifications.moduleMessages.getValue()) {
            ChatUtils.sendMessage(getChatName() + Formatting.GRAY + " " + text);
        }
    }

    public void toggle() {
        toggled = !toggled;
        if (toggled) {
            sendToggleMessage();
            playOnSound();
            onEnable();
            addToArrayList();
        } else {
            sendToggleMessage();
            playOffSound();
            onDisable();
            removeFromArrayList();
        }
    }

    protected void addToArrayList() {
        ArrayListComponent.addModule(this);
    }

    protected void removeFromArrayList() {
        ArrayListComponent.removeModule(this);
    }

    public void setToggled(boolean toggled) {
        if (this.toggled == toggled) return;
        this.toggled = toggled;
        if (this.toggled) {
            sendToggleMessage();
            playOnSound();
            addToArrayList();
            onEnable();
        } else {
            sendToggleMessage();
            playOffSound();
            removeFromArrayList();
            onDisable();
        }
    }

    public void setQuietlyToggled(boolean toggled) {
        if (this.toggled == toggled) return;
        this.toggled = toggled;
        if (this.toggled) {
            addToArrayList();
            onEnable();
        } else {
            removeFromArrayList();
            onDisable();
        }
    }

    public void sendToggleMessage() {
        if (ModuleList.chatNotifications.isEnabled() && ModuleList.chatNotifications.moduleToggle.getValue()) {
            if (toggled) {
                ChatUtils.sendMessage(this.getName() + ": " + Formatting.GREEN + "Enabled");
            } else {
                ChatUtils.sendMessage(this.getName() + ": " + Formatting.RED + "Disabled");
            }
        }
    }

}
