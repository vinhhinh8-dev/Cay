package me.ferra13671.BThack.utils;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class WorldUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isPlaceable(BlockPos position) { return isPlaceable(position, false); }

    public static boolean isPlaceable(BlockPos position, boolean excludeSelf) {
        if (!mc.world.getBlockState(position).isReplaceable()) return false;
        return mc.world.getOtherEntities(null, new Box(position)).stream()
                .noneMatch(e -> !(e instanceof EndCrystalEntity)
                        && !(e instanceof ExperienceOrbEntity)
                        && !(e instanceof ItemEntity)
                        && !(e.equals(mc.player) && excludeSelf));
    }

    public static boolean isCrystalPlaceable(BlockPos position) {
        if (!mc.world.getBlockState(position).isReplaceable()) return false;
        return mc.world.getOtherEntities(null, new Box(position)).stream()
                .noneMatch(e -> !(e instanceof EndCrystalEntity) && !(e instanceof ExperienceOrbEntity));
    }

    public static void destroyCrystals(BlockPos position) {
        List<Entity> crystals = mc.world.getOtherEntities(null, new Box(position)).stream()
                .filter(e -> e instanceof EndCrystalEntity).toList();
        if (crystals.isEmpty()) return;
        for (Entity e : crystals) {
            mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(e, mc.player.isSneaking()));
            mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            break;
        }
    }

    public static Vec3d getHitVector(BlockPos position, Direction direction) {
        return position.toCenterPos().add(
                direction.getOffsetX() / 2.0,
                direction.getOffsetY() / 2.0,
                direction.getOffsetZ() / 2.0);
    }

    public static Direction getClosestDirection(BlockPos position, boolean strictDirection) {
        if (strictDirection) {
            if (mc.player.getY() >= position.getY()) return Direction.UP;
            BlockHitResult r = mc.world.raycast(new RaycastContext(
                    mc.player.getEyePos(), Vec3d.ofCenter(position),
                    RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
            if (r == null || r.getType() != HitResult.Type.BLOCK || r.getSide() == null)
                return getClosestDirection(position);
            return r.getSide();
        }
        return getClosestDirection(position);
    }

    private static Direction getClosestDirection(BlockPos position) {
        Direction best = null;
        Vec3d bestPos = null;
        for (Direction d : Direction.values()) {
            Vec3d v = getHitVector(position, d);
            if (best == null || mc.player.squaredDistanceTo(v) < mc.player.squaredDistanceTo(bestPos)) {
                best = d; bestPos = v;
            }
        }
        return best;
    }

    public static boolean canSee(Entity entity) {
        return canSee(entity.getX(), entity.getY(), entity.getZ());
    }

    public static boolean canSee(BlockPos position) {
        return canSee(position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5);
    }

    public static boolean canSee(Vec3d vec) { return canSee(vec.x, vec.y, vec.z); }

    public static boolean canSee(double x, double y, double z) {
        return mc.world.raycast(new RaycastContext(
                new Vec3d(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ()),
                new Vec3d(x, y, z),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                mc.player)).getType() == HitResult.Type.MISS;
    }

    public static boolean canBreak(BlockPos... pos) {
        return Arrays.stream(pos).allMatch(p -> mc.world.getBlockState(p).getBlock().getHardness() != -1);
    }

    public static Block getBlock(BlockPos pos) { return mc.world.getBlockState(pos).getBlock(); }

    public static boolean equals(BlockPos x, BlockPos y) {
        if (x == null && y == null) return true;
        if (x == null || y == null) return false;
        return x.equals(y);
    }
}