package me.ferra13671.BThack.utils;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameMode;

import java.util.HashMap;
import java.util.Map;

public class DamageUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final Map<String, Integer> PROTECTION_MAP = new HashMap<>() {{
        put("protection", 1);
        put("blast_protection", 2);
        put("projectile_protection", 1);
        put("feather_falling", 1);
        put("fire_protection", 1);
    }};

    public static float getCrystalDamage(Entity entity, Box box, EndCrystalEntity crystal, boolean ignoreTerrain) {
        return getDamage(entity, box, Vec3d.ofCenter(crystal.getBlockPos(), 0), 6.0f, null, ignoreTerrain);
    }

    public static float getCrystalDamage(Entity entity, Box box, BlockPos position, BlockPos exception, boolean ignoreTerrain) {
        return getDamage(entity, box, Vec3d.ofCenter(position, 1), 6.0f, exception, ignoreTerrain);
    }

    public static float getDamage(Entity entity, Box box, Vec3d vec3d, float power, BlockPos exception, boolean ignoreTerrain) {
        if (mc.world == null || mc.player == null) return 0f;
        if (mc.world.getDifficulty() == Difficulty.PEACEFUL) return 0.0f;
        if (entity instanceof PlayerEntity player && player.isCreative()) return 0.0f;

        float diameter = power * 2.0f;
        double distance = Math.sqrt(box != null
                ? box.getCenter().add(0, -0.9, 0).squaredDistanceTo(vec3d)
                : entity.squaredDistanceTo(vec3d)) / diameter;
        if (distance > 1.0) return 0.0f;

        double exposure = (1.0 - distance) * getExposure(vec3d, entity.getBoundingBox(), exception, ignoreTerrain);
        float damage = (int) ((exposure * exposure + exposure) / 2.0 * 7.0 * diameter + 1.0);
        if (damage <= 0.0f) return 0.0f;

        if (entity instanceof LivingEntity living) {
            damage = mc.world.getDifficulty() == Difficulty.EASY
                    ? Math.min(damage / 2 + 1, damage)
                    : mc.world.getDifficulty() == Difficulty.HARD ? damage * 3 / 2 : damage;

            damage = DamageUtil.getDamageLeft(living, damage,
                    mc.world.getDamageSources().explosion(null),
                    (float) living.getArmor(),
                    (float) living.getAttributeInstance(EntityAttributes.ARMOR_TOUGHNESS).getValue());
            damage *= living.hasStatusEffect(StatusEffects.RESISTANCE)
                    ? 1 - ((living.getStatusEffect(StatusEffects.RESISTANCE).getAmplifier() + 1) * 0.2)
                    : 1;
            damage = DamageUtil.getInflictedDamage(damage, getProtectionAmount(living.getArmorItems()));
        }
        return Math.max(damage, 0.0f);
    }

    public static int getProtectionAmount(Iterable<ItemStack> armor) {
        int x = 0;
        for (ItemStack stack : armor) x += getProtectionAmount(stack);
        return x;
    }

    public static int getProtectionAmount(ItemStack armor) {
        int x = 0;
        ItemEnchantmentsComponent ench = EnchantmentHelper.getEnchantments(armor);
        for (RegistryEntry<Enchantment> e : ench.getEnchantments()) {
            String id = e.getIdAsString().replace("minecraft:", "");
            if (PROTECTION_MAP.containsKey(id)) {
                x += ench.getLevel(e) * PROTECTION_MAP.get(id);
                break;
            }
        }
        return x;
    }

    private static float getExposure(Vec3d source, Box box, BlockPos exception, boolean ignoreTerrain) {
        int hitCount = 0;
        int count = 0;
        for (double k = 0; k <= 1; k += 0.4545454446934474) {
            for (double l = 0; l <= 1; l += 0.21739130885479366) {
                for (double m = 0; m <= 1; m += 0.4545454446934474) {
                    Vec3d v = new Vec3d(
                            MathHelper.lerp(k, box.minX, box.maxX) + 0.045454555306552624,
                            MathHelper.lerp(l, box.minY, box.maxY),
                            MathHelper.lerp(m, box.minZ, box.maxZ) + 0.045454555306552624);
                    if (raycast(v, source, exception, ignoreTerrain) == HitResult.Type.MISS) hitCount++;
                    count++;
                }
            }
        }
        return (float) hitCount / (float) count;
    }

    private static HitResult.Type raycast(Vec3d start, Vec3d end, BlockPos exception, boolean ignoreTerrain) {
        return BlockView.raycast(start, end, null, (ctx, blockPos) -> {
            BlockState state;
            if (blockPos.equals(exception)) {
                state = Blocks.AIR.getDefaultState();
            } else {
                state = mc.world.getBlockState(blockPos);
                if (state.getBlock().getBlastResistance() < 600 && ignoreTerrain)
                    state = Blocks.AIR.getDefaultState();
            }
            BlockHitResult r = state.getCollisionShape(mc.world, blockPos).raycast(start, end, blockPos);
            return r == null ? null : r.getType();
        }, ctx -> HitResult.Type.MISS);
    }
}