package com.ferra13671.BThack.managers;

import com.ferra13671.BThack.BThack;
import com.ferra13671.BThack.api.module.Module;
import com.ferra13671.BThack.api.utils.Rotation;
import com.ferra13671.BThack.utils.MathUtils;
import com.ferra13671.MegaEvents.Base.EventTarget;
import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.concurrent.PriorityBlockingQueue;

public class RotationManager {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final PriorityBlockingQueue<Rotation> queue =
            new PriorityBlockingQueue<>(11, this::compareRotations);

    @Getter private Rotation rotation = null;

    private float prevFixYaw;
    private float prevYaw;
    private float prevPitch;

    @Getter private float serverYaw;
    @Getter private float serverPitch;

    private float prevRenderYaw, prevRenderPitch;
    private long lastRenderTime = 0L;

    /** Priority mặc định theo tên module. Thêm module của bạn vào đây. */
    private static final HashMap<String, Integer> PRIORITIES = new HashMap<>();
    static {
        PRIORITIES.put("KillAura", 1);
        PRIORITIES.put("AutoCrystal", 2);
        PRIORITIES.put("SpeedMine", 3);
        PRIORITIES.put("SelfFill", 4);
    }

    public RotationManager() {
        BThack.EVENT_BUS.register(this);
    }

    // ==================== EVENT HANDLERS ====================

    /**
     * Gọi đầu mỗi tick — clean queue cũ, lấy rotation hiện tại.
     * Priority Integer.MIN_VALUE để chạy trước các module khác.
     */
    @EventTarget(priority = Integer.MIN_VALUE)
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null) return;

        queue.removeIf(r -> System.currentTimeMillis() - r.getTime() > 100);
        rotation = queue.peek();

        if (rotation == null) return;
        lastRenderTime = System.currentTimeMillis();
    }

    /**
     * Gọi trước khi player update movement — ghi đè yaw/pitch tạm thời.
     * Priority Integer.MAX_VALUE để chạy sau các module khác.
     */
    @EventTarget(priority = Integer.MAX_VALUE)
    public void onUpdateMovement(UpdateMovementEvent event) {
        if (mc.player == null || rotation == null) return;

        prevYaw = mc.player.getYaw();
        prevPitch = mc.player.getPitch();

        mc.player.setYaw(rotation.getYaw());
        mc.player.setPitch(rotation.getPitch());
    }

    /** Gọi sau khi player update movement — khôi phục yaw/pitch gốc. */
    @EventTarget(priority = Integer.MIN_VALUE)
    public void onUpdateMovementPost(UpdateMovementEvent.Post event) {
        if (mc.player == null || rotation == null) return;

        mc.player.setYaw(prevYaw);
        mc.player.setPitch(prevPitch);
    }

    /**
     * Gọi khi player tính toán velocity (từ input di chuyển).
     * Đổi hướng velocity theo rotation hiện tại để movement đúng hướng.
     */
    @EventTarget
    public void onUpdateVelocity(UpdateVelocityEvent event) {
        if (mc.player == null || rotation == null) return;

        event.setVelocity(movementInputToVelocity(
                event.getMovementInput(),
                event.getSpeed(),
                rotation.getYaw()
        ));
        event.setCancelled(true);
    }

    /**
     * Gọi khi keyboard input được tick.
     * Xoay hướng đi theo rotation hiện tại.
     */
    @EventTarget
    public void onKeyboardTick(KeyboardTickEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        float movementForward = event.getMovementForward();
        float movementSideways = event.getMovementSideways();

        float delta = (mc.player.getYaw() - rotation.getYaw()) * MathHelper.RADIANS_PER_DEGREE;

        float cos = MathHelper.cos(delta);
        float sin = MathHelper.sin(delta);

        event.setMovementForward(Math.round(movementForward * cos + movementSideways * sin));
        event.setMovementSideways(Math.round(movementSideways * cos - movementForward * sin));
        event.setCancelled(true);
    }

    /**
     * Gọi khi player nhảy — cần set yaw tạm thời để nhảy đúng hướng.
     */
    @EventTarget
    public void onPlayerJump(PlayerJumpEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        prevFixYaw = mc.player.getYaw();
        mc.player.setYaw(rotation.getYaw());
    }

    /** Gọi sau khi player nhảy — khôi phục yaw gốc. */
    @EventTarget
    public void onPlayerJumpPost(PlayerJumpEvent.Post event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        if (rotation == null) return;

        mc.player.setYaw(prevFixYaw);
    }

    /**
     * Bắt packet PlayerMove để biết server đang thấy yaw/pitch nào.
     */
    @EventTarget
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null) return;

        if (event.getPacket() instanceof PlayerMoveC2SPacket packet) {
            if (!packet.changesLook()) return;

            serverYaw = packet.getYaw(mc.player.getYaw());
            serverPitch = packet.getPitch(mc.player.getPitch());
        }
    }

    // ==================== ROTATE API ====================

    /** Set rotation với priority số (không gắn module). */
    public void rotate(float[] rotations, int priority) {
        rotate(rotations[0], rotations[1], priority);
    }

    public void rotate(float yaw, float pitch, int priority) {
        queue.removeIf(r -> r.getModule() == null && r.getPriority() == priority);
        queue.add(new Rotation(yaw, pitch, priority));
    }

    /** Set rotation gắn với module — priority tự động lấy từ PRIORITIES map. */
    public void rotate(float[] rotations, Module module) {
        rotate(rotations[0], rotations[1], module);
    }

    public void rotate(float yaw, float pitch, Module module) {
        queue.removeIf(r -> r.getModule() == module);
        queue.add(new Rotation(yaw, pitch, module, getModulePriority(module)));
    }

    /** Set rotation gắn module với priority tuỳ chỉnh. */
    public void rotate(float[] rotations, Module module, int priority) {
        rotate(rotations[0], rotations[1], module, priority);
    }

    public void rotate(float yaw, float pitch, Module module, int priority) {
        queue.removeIf(r -> r.getModule() == module);
        queue.add(new Rotation(yaw, pitch, module, priority));
    }

    /** Gửi packet rotation ảo lên server (silent rotation). */
    public void packetRotate(float[] rotations) {
        packetRotate(rotations[0], rotations[1]);
    }

    public void packetRotate(float yaw, float pitch) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (serverYaw == yaw && serverPitch == pitch) return;

        serverYaw = yaw;
        serverPitch = pitch;

        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                Managers.POSITION_MANAGER.getServerX(),
                Managers.POSITION_MANAGER.getServerY(),
                Managers.POSITION_MANAGER.getServerZ(),
                yaw,
                pitch,
                Managers.POSITION_MANAGER.isServerOnGround(),
                mc.player.horizontalCollision
        ));
    }

    // ==================== RENDER ====================

    /** Có đang trong thời gian hiển thị rotation không (< 1s từ lần rotate cuối). */
    public boolean inRenderTime() {
        return System.currentTimeMillis() - lastRenderTime < 1000;
    }

    /**
     * Trả về yaw/pitch để render (đã interpolate mượt).
     * Dùng cho RenderManager hoặc module render.
     */
    public float[] getRenderRotations() {
        float from = MathUtils.wrapAngle(prevRenderYaw);
        float to = MathUtils.wrapAngle(rotation == null ? mc.player.getYaw() : getServerYaw());

        float delta = to - from;
        if (delta > 180) delta -= 360;
        else if (delta < -180) delta += 360;

        float progress = Math.min(1.0f,
                (System.currentTimeMillis() - lastRenderTime) / 1000.0f);

        float yaw = MathHelper.lerp(progress, from, from + delta);
        float pitch = MathHelper.lerp(progress, prevRenderPitch,
                rotation == null ? mc.player.getPitch() : getServerPitch());

        prevRenderYaw = yaw;
        prevRenderPitch = pitch;

        return new float[]{yaw, pitch};
    }

    // ==================== HELPERS ====================

    /** Lấy priority của module từ map, mặc định 0. */
    public int getModulePriority(Module module) {
        if (module == null) return 0;
        return PRIORITIES.getOrDefault(module.getName(), 0);
    }

    /**
     * So sánh 2 Rotation để PriorityBlockingQueue xếp đúng thứ tự.
     * Priority cao hơn → xếp trước.
     * Cùng priority → cái mới hơn xếp trước (thời gian dài hơn).
     */
    private int compareRotations(Rotation target, Rotation rotation) {
        if (target.getPriority() == rotation.getPriority()) {
            return -Long.compare(target.getTime(), rotation.getTime());
        }
        return -Integer.compare(target.getPriority(), rotation.getPriority());
    }

    /**
     * Chuyển movement input + yaw thành vector velocity.
     * Thay thế EntityAccessor.invokeMovementInputToVelocity của Sydney.
     */
    private static Vec3d movementInputToVelocity(Vec3d movementInput, float speed, float yaw) {
        double lengthSq = movementInput.lengthSquared();

        if (lengthSq < 1.0E-7) return Vec3d.ZERO;

        Vec3d vec = (lengthSq > 1.0 ? movementInput.normalize() : movementInput).multiply(speed);
        float sin = MathHelper.sin(yaw * MathHelper.RADIANS_PER_DEGREE);
        float cos = MathHelper.cos(yaw * MathHelper.RADIANS_PER_DEGREE);

        return new Vec3d(
                vec.x * cos - vec.z * sin,
                vec.y,
                vec.z * cos + vec.x * sin
        );
    }
}