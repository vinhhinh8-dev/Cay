package me.ferra13671.BThack.utils;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.*;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

public class InventoryUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static String[] SWITCH_MODES = new String[]{"None", "Normal", "Silent", "AltPickup", "AltSwap"};
    public static String[] SWAP_MODES = new String[]{"Pickup", "Swap"};

    public static int HOTBAR_START = 0;
    public static int HOTBAR_END = 8;
    public static int INVENTORY_START = 9;
    public static int INVENTORY_END = 35;

    public static void switchSlot(String mode, int slot, int previousSlot) {
        if (mode.equalsIgnoreCase("None")) return;
        if (slot == -1 || previousSlot == -1) return;

        switch (mode) {
            case "Normal" -> {
                mc.player.getInventory().selectedSlot = slot;
                if (mc.getNetworkHandler() != null)
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            }
            case "Silent" -> {
                if (mc.getNetworkHandler() != null)
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            }
            case "AltPickup" -> swap("Pickup", slot, previousSlot);
            case "AltSwap" -> swap("Swap", slot, previousSlot);
        }
    }

    public static void switchBack(String mode, int slot, int previousSlot) {
        if (mode.equalsIgnoreCase("None")) return;
        if (previousSlot == -1) return;

        switch (mode) {
            case "Silent" -> {
                if (mc.getNetworkHandler() != null)
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
            }
            case "AltPickup" -> swap("Pickup", slot, previousSlot);
            case "AltSwap" -> swap("Swap", slot, previousSlot);
        }
    }

    public static void swap(String mode, int slot, int targetSlot) {
        switch (mode) {
            case "Pickup" -> {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, indexToSlot(slot), 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, indexToSlot(targetSlot), 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, indexToSlot(slot), 0, SlotActionType.PICKUP, mc.player);
            }
            case "Swap" -> mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, indexToSlot(slot), targetSlot, SlotActionType.SWAP, mc.player);
        }
    }

    public static int indexToSlot(int index) {
        if (index >= 0 && index <= 8) return 36 + index;
        return index;
    }

    public static int find(Item item) { return find(item, HOTBAR_START, INVENTORY_END); }
    public static int findHotbar(Item item) { return find(item, HOTBAR_START, HOTBAR_END); }
    public static int findInventory(Item item) { return find(item, INVENTORY_START, INVENTORY_END); }

    public static int find(Item item, int start, int end) {
        for (int i = end; i >= start; i--) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() != item) continue;
            return i;
        }
        return -1;
    }

    public static int findBestSword(int start, int end) {
        int netherite = -1, diamond = -1, iron = -1, gold = -1, stone = -1, wood = -1;
        for (int i = end; i >= start; i--) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() == Items.NETHERITE_SWORD) netherite = i;
            if (s.getItem() == Items.DIAMOND_SWORD) diamond = i;
            if (s.getItem() == Items.IRON_SWORD) iron = i;
            if (s.getItem() == Items.GOLDEN_SWORD) gold = i;
            if (s.getItem() == Items.STONE_SWORD) stone = i;
            if (s.getItem() == Items.WOODEN_SWORD) wood = i;
        }
        if (netherite != -1) return netherite;
        if (diamond != -1) return diamond;
        if (iron != -1) return iron;
        if (gold != -1) return gold;
        if (stone != -1) return stone;
        return wood;
    }

    public static int findEmptySlot(int start, int end) {
        for (int i = end; i >= start; i--) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) continue;
            return i;
        }
        return -1;
    }

    public static boolean inInventoryScreen() {
        return mc.currentScreen instanceof InventoryScreen
                || mc.currentScreen instanceof CreativeInventoryScreen
                || mc.currentScreen instanceof GenericContainerScreen
                || mc.currentScreen instanceof ShulkerBoxScreen;
    }
}