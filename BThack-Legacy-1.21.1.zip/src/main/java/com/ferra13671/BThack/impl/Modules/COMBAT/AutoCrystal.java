package com.ferra13671.BThack.impl.Module.COMBAT;

import com.ferra13671.BThack.BThack;
import com.ferra13671.BThack.api.module.Module;
import com.ferra13671.BThack.api.setting.settings.*;
import com.ferra13671.BThack.api.utils.ColorUtils;
import com.ferra13671.BThack.managers.Managers;
import com.ferra13671.BThack.utils.*;
import com.ferra13671.MegaEvents.Base.EventTarget;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.ExperienceOrbSpawnS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AutoCrystal extends Module {

    // ==================== SETTINGS ====================
    // ATTACK
    public BooleanSetting attack = new BooleanSetting("Attack", true);
    public NumberSetting attackSpeed = new NumberSetting("AttackSpeed", 20f, 0.1f, 20f, 0.1f);
    public NumberSetting attackRange = new NumberSetting("AttackRange", 4.5f, 0f, 8f, 0.1f);
    public NumberSetting attackWallsRange = new NumberSetting("AttackWallsRange", 4.5f, 0f, 8f, 0.1f);
    public ModeSetting antiWeakness = new ModeSetting("AntiWeakness", "None", "None", "Normal", "Silent");
    public BooleanSetting instant = new BooleanSetting("Instant", true);
    public BooleanSetting inhibit = new BooleanSetting("Inhibit", true);

    // PLACE
    public BooleanSetting place = new BooleanSetting("Place", true);
    public NumberSetting placeSpeed = new NumberSetting("PlaceSpeed", 20f, 0.1f, 20f, 0.1f);
    public NumberSetting placeRange = new NumberSetting("PlaceRange", 4.5f, 0f, 8f, 0.1f);
    public NumberSetting placeWallsRange = new NumberSetting("PlaceWallsRange", 4.5f, 0f, 8f, 0.1f);
    public ModeSetting placements = new ModeSetting("Placements", "Native", "Native", "Protocol");
    public BooleanSetting blockDestruction = new BooleanSetting("BlockDestruction", true);
    public ModeSetting autoSwitch = new ModeSetting("Switch", "None", "None", "Normal", "Silent", "AltSwap");

    // MISC
    public ModeSetting sequential = new ModeSetting("Sequential", "Strong", "None", "Strict", "Strong");
    public ModeSetting rotate = new ModeSetting("Rotate", "Normal", "None", "Normal", "Packet");
    public ModeSetting swing = new ModeSetting("Swing", "Default", "Default", "None", "Packet", "Mainhand", "Offhand", "Both");
    public BooleanSetting yawStep = new BooleanSetting("YawStep", false);
    public NumberSetting yawStepThreshold = new NumberSetting("YawStepThreshold", 75f, 1f, 180f, 1f);
    public BooleanSetting raytrace = new BooleanSetting("Raytrace", false);
    public NumberSetting extrapolation = new NumberSetting("Extrapolation", 0f, 0f, 20f, 1f);
    public NumberSetting enemyRange = new NumberSetting("EnemyRange", 10f, 0f, 24f, 0.1f);
    public BooleanSetting chestBreak = new BooleanSetting("ChestBreak", false);
    public BooleanSetting asynchronous = new BooleanSetting("Asynchronous", true);
    public BooleanSetting gameLoop = new BooleanSetting("GameLoop", false);
    public NumberSetting loopDelay = new NumberSetting("LoopDelay", 50f, 0f, 1000f, 1f);
    public ModeSetting whileEating = new ModeSetting("WhileEating", "Both", "None", "Attack", "Place", "Both");

    // PREDICTION
    public BooleanSetting godSync = new BooleanSetting("GodSync", false);
    public NumberSetting predictions = new NumberSetting("Predictions", 10f, 1f, 20f, 1f);
    public NumberSetting offset = new NumberSetting("Offset", 0f, 0f, 2f, 1f);
    public ModeSetting godSwing = new ModeSetting("GodSwing", "Normal", "None", "Normal", "Strict");
    public BooleanSetting fast = new BooleanSetting("Fast", false);
    public BooleanSetting antiKick = new BooleanSetting("AntiKick", false);
    public NumberSetting kickThreshold = new NumberSetting("KickThreshold", 5f, 1f, 10f, 1f);

    // FACEPLACE
    public ModeSetting facePlaceMode = new ModeSetting("FaceplaceMode", "Dynamic", "None", "Dynamic", "Always");
    public ModeSetting facePlaceSpeed = new ModeSetting("FaceplaceSpeed", "Normal", "Normal", "Custom");
    public NumberSetting facePlaceDelay = new NumberSetting("FaceplaceDelay", 11f, 0f, 20f, 1f);
    public BooleanSetting healthPlace = new BooleanSetting("HealthPlace", true);
    public NumberSetting health = new NumberSetting("Health", 8f, 0f, 36f, 0.1f);
    public BooleanSetting armorPlace = new BooleanSetting("ArmorPlace", true);
    public NumberSetting percentage = new NumberSetting("Percentage", 10f, 1f, 100f, 1f);

    // DAMAGE
    public NumberSetting minimumDamage = new NumberSetting("MinimumDamage", 6f, 0f, 36f, 0.1f);
    public NumberSetting maximumSelfDamage = new NumberSetting("MaximumSelfDamage", 10f, 0f, 36f, 0.1f);
    public NumberSetting lethalMultiplier = new NumberSetting("LethalMultiplier", 1.5f, 0f, 4f, 0.1f);
    public BooleanSetting antiSuicide = new BooleanSetting("AntiSuicide", true);
    public BooleanSetting ignoreTerrain = new BooleanSetting("IgnoreTerrain", true);

    // RENDER
    public ModeSetting animationMode = new ModeSetting("Animation", "Static", "Static", "Slide");
    public ModeSetting renderMode = new ModeSetting("RenderMode", "Both", "None", "Fill", "Outline", "Both");
    public ColorSetting fillColorUp = new ColorSetting("FillColorUp", ColorUtils.getDefaultFillColor());
    public ColorSetting fillColorDown = new ColorSetting("FillColorDown", ColorUtils.getDefaultFillColor());
    public ColorSetting outlineColorUp = new ColorSetting("OutlineColorUp", ColorUtils.getDefaultOutlineColor());
    public ColorSetting outlineColorDown = new ColorSetting("OutlineColorDown", ColorUtils.getDefaultOutlineColor());
    public BooleanSetting renderDamage = new BooleanSetting("RenderDamage", false);
    public BooleanSetting icon = new BooleanSetting("Icon", false);
    public NumberSetting iconScale = new NumberSetting("IconScale", 3f, 1f, 5f, 1f);
    public NumberSetting iconRadius = new NumberSetting("IconRadius", 2f, 0f, 5f, 0.1f);
    public ColorSetting iconColor = new ColorSetting("IconColor", ColorUtils.getDefaultColor());

    // ==================== STATE ====================
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Runnable attackRunnable = null;
    private Runnable placeRunnable = null;

    private final Map<Integer, Long> attackedCrystals = new ConcurrentHashMap<>();
    private final Map<BlockPos, Long> placedCrystals = new ConcurrentHashMap<>();
    private final Map<BlockPos, Long> countedCrystals = new ConcurrentHashMap<>();

    private final Timer attackTimer = new Timer();
    private final Timer placeTimer = new Timer();
    private final Timer facePlaceTimer = new Timer();
    private final Timer loopTimer = new Timer();

    private boolean sequenceAttack = false;
    private boolean sequencePlace = true;
    private boolean attackedSequentially = false;
    private boolean placedSequentially = false;

    private PlayerEntity target = null;
    private EndCrystalEntity attackTarget = null;
    private PlaceTarget placeTarget = null;
    private PlaceTarget mineTarget = null;

    private String calculationTime = "0.00ms";
    private int calculationCount = 0;
    private String calculationDamage = "0.00";

    private final Counter crystalCounter = new Counter();
    private int crystalsPerSecond = 0;

    private int highestID = -100000;
    private int kickTicks = 0;

    public AutoCrystal() {
        super("AutoCrystal", "Automatically places and attacks crystals to annihilate your opponents.", Category.COMBAT);

        // Đăng ký settings (tùy API BThack - có thể là addSettings(...) hoặc reflection)
        // addSettings(attack, attackSpeed, ... tất cả setting ở trên);
    }

    @Override
    public void onEnable() {
        reset();
    }

    @Override
    public void onDisable() {
        reset();
        Managers.RENDER_MANAGER.clearCustomRender(); // đổi theo API BThack
    }

    private void reset() {
        attackRunnable = null;
        placeRunnable = null;
        attackedCrystals.clear();
        placedCrystals.clear();
        countedCrystals.clear();
        attackedSequentially = false;
        placedSequentially = false;
        target = null;
        placeTarget = null;
        mineTarget = null;
        calculationTime = "0.00ms";
        calculationCount = 0;
        calculationDamage = "0.00";
        crystalCounter.reset();
        crystalsPerSecond = 0;
        highestID = -100000;
        kickTicks = 0;
    }

    // ==================== EVENTS ====================

    @EventTarget
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;

        long now = System.currentTimeMillis();
        long timeout = ping() * 2L;
        long extra = (long) ((20 - attackSpeed.getValue()) * 50);

        attackedCrystals.entrySet().removeIf(e -> now - e.getValue() > timeout);
        placedCrystals.entrySet().removeIf(e -> now - e.getValue() > timeout + extra);
        countedCrystals.entrySet().removeIf(e -> now - e.getValue() > timeout);

        crystalsPerSecond = crystalCounter.getCount();

        Runnable task = () -> {
            long start = System.nanoTime();
            attackTarget = calculateCrystals();
            placeTarget = calculatePlacements(null);
            calculationTime = new DecimalFormat("0.00").format((System.nanoTime() - start) / 1_000_000.0) + "ms";
            calculationCount = placeTarget == null ? 0 : placeTarget.calculations;
            calculationDamage = placeTarget == null ? "0.00" : new DecimalFormat("0.00").format(placeTarget.damage);
            target = placeTarget == null ? null : placeTarget.player;

            if (blockDestruction.getValue() && asynchronous.getValue()) {
                // Port SpeedMine check nếu có module đó trong BThack
                BlockPos position = null;
                if (position != null) mineTarget = calculatePlacements(position);
            }
        };

        if (asynchronous.getValue()) executor.submit(task);
        else task.run();

        if (gameLoop.getValue()) return;
        run();
    }

    @EventTarget
    public void onGameLoop(GameLoopEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (!gameLoop.getValue()) return;
        if (!loopTimer.hasTimeElapsed(loopDelay.getValue().longValue())) return;

        loopTimer.reset();
        run();

        if (attackRunnable != null) { attackRunnable.run(); attackRunnable = null; }
        if (placeRunnable != null) { placeRunnable.run(); placeRunnable = null; }
    }

    @EventTarget
    public void onUpdateMovementPost(UpdateMovementEvent.Post event) {
        if (mc.player == null || mc.world == null) return;
        if (attackRunnable != null) { attackRunnable.run(); attackRunnable = null; }
        if (placeRunnable != null) { placeRunnable.run(); placeRunnable = null; }
    }

    @EventTarget
    public void onEntitySpawn(EntitySpawnEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (!attack.getValue() || !instant.getValue()) return;
        if (!attackTimer.hasTimeElapsed(1000f - attackSpeed.getValue() * 50f)) return;
        if (!(event.getEntity() instanceof EndCrystalEntity crystal)) return;

        if (inhibit.getValue() && attackedCrystals.containsKey(crystal.getId())) return;
        if (!placedCrystals.containsKey(crystal.getBlockPos().down())) return;
        if (crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackRange.getValue().doubleValue())) return;
        if (!mc.world.getWorldBorder().contains(crystal.getBlockPos())) return;
        if (!WorldUtils.canSee(crystal) && (raytrace.getValue() ||
                crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackWallsRange.getValue().doubleValue()))) return;

        if (rotate.getValue().equals("Packet"))
            Managers.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(Vec3d.ofCenter(crystal.getBlockPos(), 0)));
        if (rotate.getValue().equals("Normal"))
            Managers.ROTATION_MANAGER.rotate(calculateRotations(Vec3d.ofCenter(crystal.getBlockPos(), 0)), this);

        attack(crystal);
        attackedSequentially = true;
        if (sequential.getValue().equals("Strong")) placeCrystals(true);
    }

    @EventTarget
    public void onDestroyBlock(DestroyBlockEvent event) {
        if (mc.player == null || mc.world == null) return;
        kickTicks = 0;
        if (!blockDestruction.getValue()) return;
        if (!placeTimer.hasTimeElapsed(1000f - placeSpeed.getValue() * 50f)) return;

        BlockPos minedPosition = event.getPosition();
        if (minedPosition == null) return;

        int slot = InventoryUtils.findHotbar(Items.END_CRYSTAL);
        int previousSlot = mc.player.getInventory().selectedSlot;
        boolean holding = mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL
                || mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL;

        if (!autoSwitch.getValue().equals("None") && slot == -1 && !holding) return;

        PlaceTarget mt = mineTarget == null ? null : mineTarget.clone();
        if (mt == null || (mt.position != null && !minedPosition.equals(mt.exception)))
            mt = calculatePlacements(minedPosition);
        if (mt == null || mt.position == null) {
            Managers.RENDER_MANAGER.clearCustomRender();
            return;
        }

        BlockPos position = mt.position;
        Managers.RENDER_MANAGER.setRenderPosition(position);

        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeRange.getValue().doubleValue())) return;
        if (!WorldUtils.canSee(position) && (raytrace.getValue() ||
                mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeWallsRange.getValue().doubleValue()))) return;

        if (rotate.getValue().equals("Normal"))
            Managers.ROTATION_MANAGER.rotate(calculateRotations(Vec3d.ofCenter(position, 1)), this, Managers.ROTATION_MANAGER.getModulePriority(this) + 1);
        if (!rotate.getValue().equals("None"))
            Managers.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(Vec3d.ofCenter(position, 1)));

        for (Entity entity : mc.world.getOtherEntities(null, new Box(position.up()))) {
            if (!(entity instanceof EndCrystalEntity)) continue;
            if (!rotate.getValue().equals("None"))
                Managers.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(entity));
            mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, mc.player.isSneaking()));
            mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            break;
        }

        boolean switched = false;
        if (!autoSwitch.getValue().equals("None") && !holding) {
            InventoryUtils.switchSlot(autoSwitch.getValue(), slot, previousSlot);
            switched = true;
        }
        place(position);
        if (switched) InventoryUtils.switchBack(autoSwitch.getValue(), slot, previousSlot);
    }

    @EventTarget
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (event.getPacket() instanceof EntitySpawnS2CPacket packet) {
            if (packet.getEntityId() > highestID) highestID = packet.getEntityId();
            BlockPos position = BlockPos.ofFloored(packet.getX(), packet.getY(), packet.getZ()).add(0, -1, 0);
            if (countedCrystals.containsKey(position)) {
                if (facePlaceTimer.hasTimeElapsed(facePlaceDelay.getValue().longValue() * 50L))
                    facePlaceTimer.reset();
                countedCrystals.remove(position);
                crystalCounter.increment();
                crystalsPerSecond = crystalCounter.getCount();
            }
        }

        if (event.getPacket() instanceof ExperienceOrbSpawnS2CPacket packet) {
            if (packet.getEntityId() > highestID) highestID = packet.getEntityId();
        }
    }

    @EventTarget
    public void onPlayerDeath(PlayerDeathEvent event) { kickTicks = 0; }

    @EventTarget
    public void onClientConnect(ClientConnectEvent event) { highestID = -100000; }

    // ==================== CORE ====================

    private void run() {
        attackRunnable = null;
        placeRunnable = null;

        if (sequential.getValue().equals("None")) {
            if (sequenceAttack) {
                sequenceAttack = false;
                sequencePlace = true;
                attackCrystals();
                return;
            }
            if (sequencePlace) {
                sequenceAttack = true;
                sequencePlace = false;
                placeCrystals(false);
            }
        } else {
            if (attack.getValue()) attackCrystals();
            if (place.getValue()) placeCrystals(false);
        }
    }

    private void attackCrystals() {
        EndCrystalEntity overrideCrystal = null;
        boolean flag = placeTarget != null && placeTarget.obstructions != null && !placeTarget.obstructions.isEmpty();
        Iterable<Entity> pool = flag ? placeTarget.obstructions : mc.world.getEntities();

        for (Entity entity : pool) {
            if (!(entity instanceof EndCrystalEntity crystal)) continue;
            if (!crystal.isAlive()) continue;
            if (inhibit.getValue() && attackedCrystals.containsKey(entity.getId())) continue;
            if (!flag && !placedCrystals.containsKey(crystal.getBlockPos().down())) continue;
            if (crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackRange.getValue().doubleValue())) continue;
            if (!mc.world.getWorldBorder().contains(crystal.getBlockPos())) continue;
            if (!WorldUtils.canSee(crystal) && (raytrace.getValue() ||
                    crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackWallsRange.getValue().doubleValue()))) continue;
            overrideCrystal = crystal;
            break;
        }

        EndCrystalEntity crystal = overrideCrystal == null ? attackTarget : overrideCrystal;
        if (crystal == null) return;

        if (rotate.getValue().equals("Normal"))
            Managers.ROTATION_MANAGER.rotate(calculateRotations(Vec3d.ofCenter(crystal.getBlockPos(), 0)), this);

        if (!attackTimer.hasTimeElapsed(1000f - attackSpeed.getValue() * 50f) || attackedSequentially) {
            if (attackedSequentially) attackedSequentially = false;
            return;
        }

        Entity entity = mc.world.getEntityById(crystal.getId());
        if (!(entity instanceof EndCrystalEntity endCrystal)) return;
        if (!endCrystal.isAlive()) return;
        if (inhibit.getValue() && attackedCrystals.containsKey(entity.getId())) return;
        if (endCrystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackRange.getValue().doubleValue())) return;
        if (!mc.world.getWorldBorder().contains(endCrystal.getBlockPos())) return;
        if (!WorldUtils.canSee(endCrystal) && (raytrace.getValue() ||
                endCrystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackWallsRange.getValue().doubleValue()))) return;

        EndCrystalEntity finalCrystal = crystal;
        attackRunnable = () -> {
            if (rotate.getValue().equals("Packet"))
                Managers.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(Vec3d.ofCenter(finalCrystal.getBlockPos(), 0)));
            attack(finalCrystal);
        };
    }

    private void placeCrystals(boolean sequentialCall) {
        PlaceTarget pt = placeTarget == null ? null : placeTarget.clone();
        if (pt == null || pt.position == null) {
            Managers.RENDER_MANAGER.clearCustomRender();
            return;
        }

        int slot = InventoryUtils.findHotbar(Items.END_CRYSTAL);
        int previousSlot = mc.player.getInventory().selectedSlot;
        boolean holding = mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL
                || mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL;

        if (!autoSwitch.getValue().equals("None") && slot == -1 && !holding) return;

        BlockPos position = pt.position;
        Managers.RENDER_MANAGER.setRenderPosition(position);

        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeRange.getValue().doubleValue())) return;
        if (!mc.world.getWorldBorder().contains(position)) return;
        if (mc.world.getBlockState(position).getBlock() != Blocks.OBSIDIAN
                && mc.world.getBlockState(position).getBlock() != Blocks.BEDROCK) return;
        if (!mc.world.getBlockState(position.add(0, 1, 0)).isAir()) return;
        if (placements.getValue().equals("Protocol") && !mc.world.getBlockState(position.add(0, 2, 0)).isAir()) return;
        if (!WorldUtils.canSee(position) && (raytrace.getValue() ||
                mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeWallsRange.getValue().doubleValue()))) return;
        if (mc.world.getOtherEntities(null, new Box(position.add(0, 1, 0))).stream()
                .anyMatch(e -> e.isAlive() && !(e instanceof ExperienceOrbEntity) && !(e instanceof EndCrystalEntity))) return;

        if (rotate.getValue().equals("Normal"))
            Managers.ROTATION_MANAGER.rotate(calculateRotations(Vec3d.ofCenter(position, 1)), this);

        if (!placeTimer.hasTimeElapsed(1000f - placeSpeed.getValue() * 50f)) return;
        if (!sequentialCall && placedSequentially) {
            placedSequentially = false;
            return;
        }

        BlockPos finalPos = position;
        int finalSlot = slot;
        int finalPrev = previousSlot;
        boolean finalHolding = holding;

        placeRunnable = () -> {
            boolean switched = false;

            if (rotate.getValue().equals("Packet"))
                Managers.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(Vec3d.ofCenter(finalPos, 1)));

            if (!finalHolding) {
                InventoryUtils.switchSlot(autoSwitch.getValue(), finalSlot, finalPrev);
                switched = true;
            }

            place(finalPos);

            if (switched) InventoryUtils.switchBack(autoSwitch.getValue(), finalSlot, finalPrev);

            if (godSync.getValue()) doGodSync();
        };

        if (sequentialCall) {
            placeRunnable.run();
            placeRunnable = null;
            placedSequentially = true;
        }
    }

    private void doGodSync() {
        boolean flag = !antiKick.getValue()
                || (!(mc.player.getMainHandStack().getItem() instanceof ExperienceBottleItem)
                    && !(mc.player.getOffHandStack().getItem() instanceof ExperienceBottleItem));
        // TODO: nếu có ThrowXPModule → check thêm

        if (antiKick.getValue() && kickTicks <= kickThreshold.getValue().intValue()) { kickTicks++; return; }
        if (!flag) return;

        if (!fast.getValue()) {
            for (Entity entity : mc.world.getEntities()) {
                if (entity.getId() > highestID) highestID = entity.getId();
            }
        }

        for (int i = 1 - offset.getValue().intValue(); i < predictions.getValue().intValue(); ++i) {
            Entity entity = mc.world.getEntityById(highestID);
            if (entity == null || entity instanceof EndCrystalEntity) {
                int id = highestID + i;

                PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(mc.player, mc.player.isSneaking());
                try {
                    Field field = PlayerInteractEntityC2SPacket.class.getDeclaredField("entityId");
                    field.setAccessible(true);
                    field.setInt(packet, id);
                } catch (Exception ignored) {}

                mc.getNetworkHandler().sendPacket(packet);
                if (godSwing.getValue().equals("Strict"))
                    mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));

                attackedCrystals.put(id, System.currentTimeMillis());
            }
        }

        if (godSwing.getValue().equals("Normal"))
            mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));

        kickTicks++;
    }

    private EndCrystalEntity calculateCrystals() {
        if (!attack.getValue()) return null;
        if (shouldPause("Attack")) return null;

        List<PlayerEntity> players = getPlayers();
        if (players.isEmpty()) return null;

        EndCrystalEntity optimal = null;
        float optimalDamage = 0f;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity crystal)) continue;
            if (!crystal.isAlive()) continue;
            if (inhibit.getValue() && attackedCrystals.containsKey(entity.getId())) continue;
            if (crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackRange.getValue().doubleValue())) continue;
            if (!mc.world.getWorldBorder().contains(crystal.getBlockPos())) continue;
            if (!WorldUtils.canSee(crystal) && (raytrace.getValue() ||
                    crystal.getBoundingBox().squaredMagnitude(mc.player.getEyePos()) > MathHelper.square(attackWallsRange.getValue().doubleValue()))) continue;

            float selfDamage = DamageUtils.getCrystalDamage(mc.player, null, crystal, ignoreTerrain.getValue());
            if (selfDamage > maximumSelfDamage.getValue().floatValue()) continue;
            if (antiSuicide.getValue() && selfDamage > mc.player.getHealth() + mc.player.getAbsorptionAmount()) continue;

            boolean override = false;
            for (PlayerEntity player : players) {
                float damage = DamageUtils.getCrystalDamage(player, PositionUtils.extrapolate(player, extrapolation.getValue().intValue()),
                        crystal, ignoreTerrain.getValue());
                float minD = getMinimumDamage(player, minimumDamage.getValue().floatValue());
                if (damage < minD && damage < player.getHealth() + player.getAbsorptionAmount()
                        && !(damage * (1f + lethalMultiplier.getValue().floatValue()) >= player.getHealth() + player.getAbsorptionAmount())) continue;

                if (damage > optimalDamage || damage > player.getHealth() + player.getAbsorptionAmount()) {
                    optimal = crystal;
                    optimalDamage = damage;
                    if (damage > player.getHealth() + player.getAbsorptionAmount()) {
                        override = true;
                        break;
                    }
                }
            }
            if (override) break;
        }
        return optimal;
    }

    private PlaceTarget calculatePlacements(BlockPos exception) {
        if (!place.getValue()) return null;
        if (shouldPause("Place")) return null;

        boolean holding = mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL
                || mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL;
        if ((autoSwitch.getValue().equals("None") || InventoryUtils.findHotbar(Items.END_CRYSTAL) == -1) && !holding) return null;

        List<PlayerEntity> players = getPlayers();
        if (players.isEmpty()) return null;

        BlockPos optimalPosition = null;
        PlayerEntity optimalPlayer = null;
        List<Entity> obstructions = new ArrayList<>();
        float optimalDamage = 0f;
        int calculations = 0;

        double maxRange = Math.max(placeRange.getValue().doubleValue(), placeWallsRange.getValue().doubleValue());
        int radius = MathHelper.ceil(maxRange);
        BlockPos playerPos = mc.player.getBlockPos();

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos position = playerPos.add(x, y, z);

                    if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeRange.getValue().doubleValue())) continue;
                    if (!mc.world.getWorldBorder().contains(position)) continue;
                    if (mc.world.getBlockState(position).getBlock() != Blocks.OBSIDIAN
                            && mc.world.getBlockState(position).getBlock() != Blocks.BEDROCK) continue;
                    if (!mc.world.getBlockState(position.add(0, 1, 0)).isAir()) continue;
                    if (placements.getValue().equals("Protocol") && !mc.world.getBlockState(position.add(0, 2, 0)).isAir()) continue;
                    if (!WorldUtils.canSee(position) && (raytrace.getValue() ||
                            mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(position)) > MathHelper.square(placeWallsRange.getValue().doubleValue()))) continue;
                    if (mc.world.getOtherEntities(null, new Box(position.add(0, 1, 0))).stream()
                            .anyMatch(e -> e.isAlive() && !(e instanceof ExperienceOrbEntity) && !(e instanceof EndCrystalEntity))) continue;

                    List<Entity> obst = mc.world.getOtherEntities(null, new Box(position.add(0, 1, 0))).stream()
                            .filter(e -> e instanceof EndCrystalEntity c && c.age >= (20 - attackSpeed.getValue().intValue()) + 15)
                            .toList();

                    float selfDamage = DamageUtils.getCrystalDamage(mc.player, null, position, exception, ignoreTerrain.getValue());
                    if (selfDamage > maximumSelfDamage.getValue().floatValue()) continue;
                    if (antiSuicide.getValue() && selfDamage > mc.player.getHealth() + mc.player.getAbsorptionAmount()) continue;

                    boolean override = false;
                    for (PlayerEntity player : players) {
                        calculations++;
                        float damage = DamageUtils.getCrystalDamage(player,
                                PositionUtils.extrapolate(player, extrapolation.getValue().intValue()),
                                position, exception, ignoreTerrain.getValue());
                        float minD = getMinimumDamage(player, minimumDamage.getValue().floatValue());
                        if (damage < minD && damage < player.getHealth() + player.getAbsorptionAmount()
                                && !(damage * (1f + lethalMultiplier.getValue().floatValue()) >= player.getHealth() + player.getAbsorptionAmount())) continue;

                        if (exception == null && !obst.isEmpty()) {
                            obstructions.add(obst.get(0));
                            break;
                        }

                        if (damage > optimalDamage || damage > player.getHealth() + player.getAbsorptionAmount()) {
                            optimalPosition = position;
                            optimalPlayer = player;
                            optimalDamage = damage;
                            if (damage > player.getHealth() + player.getAbsorptionAmount()) {
                                override = true;
                                break;
                            }
                        }
                    }
                    if (override) break;
                }
            }
        }

        if (optimalPosition == null) return new PlaceTarget(null, null, obstructions, null, 0f, calculations);
        return new PlaceTarget(optimalPosition, optimalPlayer, obstructions, exception, optimalDamage, calculations);
    }

    private float[] calculateRotations(Vec3d vec) {
        float[] rotations = RotationUtils.getRotations(vec);
        if (yawStep.getValue()) {
            float difference = Managers.ROTATION_MANAGER.getServerYaw() - rotations[0];
            if (Math.abs(difference) > 180f) difference += difference > 0f ? -360f : 360f;

            float deltaYaw = (difference > 0f ? -1 : 1) * yawStepThreshold.getValue().floatValue();
            if (Math.abs(difference) > yawStepThreshold.getValue().floatValue())
                rotations[0] = Managers.ROTATION_MANAGER.getServerYaw() + deltaYaw;
        }
        return rotations;
    }

    private void attack(EndCrystalEntity crystal) {
        int previousSlot = mc.player.getInventory().selectedSlot;
        boolean switched = false;

        if (!antiWeakness.getValue().equals("None") && mc.player.hasStatusEffect(StatusEffects.WEAKNESS)) {
            int slot = InventoryUtils.findBestSword(InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
            if (slot != -1) {
                InventoryUtils.switchSlot(antiWeakness.getValue(), slot, previousSlot);
                switched = true;
            }
        }

        mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(crystal, mc.player.isSneaking()));
        mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));

        if (switched) InventoryUtils.switchBack(antiWeakness.getValue(), 0, previousSlot);

        attackedCrystals.put(crystal.getId(), System.currentTimeMillis());
        attackTimer.reset();
    }

    private void place(BlockPos position) {
        Hand hand = mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL ? Hand.OFF_HAND : Hand.MAIN_HAND;
        Direction direction = WorldUtils.getClosestDirection(position, true);

        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(hand,
                new BlockHitResult(WorldUtils.getHitVector(position, direction), direction, position, false), 0));

        switch (swing.getValue()) {
            case "Default" -> mc.player.swingHand(hand);
            case "Packet" -> mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
            case "Mainhand" -> mc.player.swingHand(Hand.MAIN_HAND);
            case "Offhand" -> mc.player.swingHand(Hand.OFF_HAND);
            case "Both" -> {
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.swingHand(Hand.OFF_HAND);
            }
        }

        placedCrystals.put(position, System.currentTimeMillis());
        countedCrystals.put(position, System.currentTimeMillis());
        placeTimer.reset();
    }

    private List<PlayerEntity> getPlayers() {
        List<PlayerEntity> players = new ArrayList<>();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!player.isAlive()) continue;
            if (mc.player.squaredDistanceTo(player) > MathHelper.square(enemyRange.getValue().doubleValue())) continue;
            if (Managers.FRIEND_MANAGER != null && Managers.FRIEND_MANAGER.contains(player.getName().getString())) continue;
            players.add(player);
        }
        return players;
    }

    private boolean shouldPause(String process) {
        boolean eatingFlag = whileEating.getValue().equals("None")
                || (process.equals("Attack") && whileEating.getValue().equals("Place"))
                || (process.equals("Place") && whileEating.getValue().equals("Attack"));
        return eatingFlag && mc.player.isUsingItem();
    }

    private float getMinimumDamage(PlayerEntity player, float minimumDamage) {
        if (player == null) return minimumDamage;

        if (chestBreak.getValue() && mc.world.getOtherEntities(null, new Box(player.getBlockPos()).expand(1)).stream()
                .anyMatch(e -> e instanceof ItemEntity item && item.getStack().getItem() == Items.OBSIDIAN
                        && item.getStack().getCount() >= 8 && item.age <= 2 + ping() / 50 + (20 - placeSpeed.getValue().intValue()))
                && !mc.world.getOtherEntities(null, new Box(mc.player.getBlockPos()).expand(1)).stream()
                .anyMatch(e -> e instanceof ItemEntity item && item.getStack().getItem() == Items.OBSIDIAN
                        && item.getStack().getCount() >= 8 && item.age <= 2 + ping() / 50 + (20 - placeSpeed.getValue().intValue())))
            return 2f;

        if (facePlaceMode.getValue().equals("None")) return minimumDamage;

        boolean canFace = facePlaceSpeed.getValue().equals("Normal")
                || facePlaceTimer.hasTimeElapsed(facePlaceDelay.getValue().longValue() * 50L);

        if (canFace) {
            if (facePlaceMode.getValue().equals("Always")) return Math.min(minimumDamage, 2f);
            if (facePlaceMode.getValue().equals("Dynamic") && healthPlace.getValue()
                    && player.getHealth() + player.getAbsorptionAmount() <= health.getValue().floatValue())
                return Math.min(minimumDamage, 2f);
            if (facePlaceMode.getValue().equals("Dynamic") && armorPlace.getValue()) {
                for (ItemStack stack : player.getArmorItems()) {
                    if (stack == null || !(stack.getItem() instanceof ArmorItem)) continue;
                    if (Math.round(((stack.getMaxDamage() - stack.getDamage()) * 100.0) / stack.getMaxDamage()) <= percentage.getValue().intValue())
                        return Math.min(minimumDamage, 2f);
                }
            }
        }
        return minimumDamage;
    }

    private long ping() {
        // Thay bằng API ping của BThack
        try {
            return Objects.requireNonNull(mc.getNetworkHandler()).getPlayerListEntry(mc.player.getUuid()).getLatency();
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public String getMetaData() {
        return calculationTime + ", " + calculationCount + ", " + calculationDamage + ", " + crystalsPerSecond;
    }

    public PlayerEntity getTarget() { return target; }
    public String getCalculationDamage() { return calculationDamage; }

    public static class PlaceTarget {
        public BlockPos position;
        public PlayerEntity player;
        public List<Entity> obstructions;
        public BlockPos exception;
        public float damage;
        public int calculations;

        public PlaceTarget(BlockPos p, PlayerEntity pl, List<Entity> o, BlockPos ex, float d, int c) {
            position = p; player = pl; obstructions = o; exception = ex; damage = d; calculations = c;
        }

        public PlaceTarget clone() {
            return new PlaceTarget(position, player, obstructions, exception, damage, calculations);
        }
    }
}