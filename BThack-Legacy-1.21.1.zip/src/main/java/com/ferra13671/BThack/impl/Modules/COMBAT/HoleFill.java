package com.ferra13671.BThack.impl.Modules.COMBAT;

import com.ferra13671.BThack.api.Events.ClientTickEvent;
import com.ferra13671.BThack.api.Managers.managers.Build.BuildManager;
import com.ferra13671.BThack.api.Managers.managers.Build.BuildThread3D;
import com.ferra13671.BThack.api.Managers.managers.Setting.Settings.BooleanSetting;
import com.ferra13671.BThack.api.Module.Module;
import com.ferra13671.BThack.api.Module.ModuleInfo;
import com.ferra13671.BThack.api.Utils.BlockUtils;
import com.ferra13671.BThack.api.Utils.HoleUtils;
import com.ferra13671.BThack.api.Utils.MathUtils;
import com.ferra13671.MegaEvents.Base.EventSubscriber;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

@ModuleInfo(name = "HoleFill", description = "lang.module.HoleFill", category = "COMBAT")
public class HoleFill extends Module {

    public final BooleanSetting onlyObsidian = new BooleanSetting("Only Obsidian", this, true);


    @EventSubscriber
    public void onTick(ClientTickEvent e) {
        if (nullCheck() || BuildManager.isBuilding) return;

        ArrayList<BlockPos> blockPoses = new ArrayList<>();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (HoleUtils.isMutableHole(mc.player.getBlockPos(), false)) {
                blockPoses.add(player.getBlockPos());
            }
        }

        BlockPos blockPos = BlockUtils.getSphere(mc.player.getBlockPos(), 4, 4, false, true, 0).stream().filter(blockPos1 -> HoleUtils.isMutableHole(blockPos1, false) && !blockPoses.contains(blockPos1))
                .min(Comparator.comparing(blockPos2 -> MathUtils.getDistance(mc.player.getPos(), blockPos2.toCenterPos()))).orElse(null);

        if (blockPos == null) return;

        BuildThread3D builder3D = new BuildThread3D();
        builder3D.set3DSchematic(0, new ArrayList<>(List.of(blockPos)), new BlockPos(0,0,0));
        builder3D.setNeedBlocks(onlyObsidian.getValue() ? Arrays.asList(Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN) : new ArrayList<>());
        builder3D.start();
    }
}
